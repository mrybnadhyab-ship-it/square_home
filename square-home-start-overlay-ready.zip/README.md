# Square Home Start Overlay patch

This patch targets upstream commit `b529590` of `qw75106/square_home`.

It keeps the existing Tiles/UI and Launcher behavior, and adds a transparent Activity mode that can be opened by OpenNavBar with:

- package: `com.squarehome`
- class: `com.squarehome.MainActivity`
- extra: `start_overlay=true`

When a Tile launches an app, the overlay Activity is finished first.

This is an Activity-based transparent overlay, not a `TYPE_APPLICATION_OVERLAY` service, so it does not require `SYSTEM_ALERT_WINDOW`.
