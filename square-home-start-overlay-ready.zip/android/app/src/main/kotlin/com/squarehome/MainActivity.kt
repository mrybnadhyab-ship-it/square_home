package com.squarehome

import android.content.Intent
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    companion object {
        private const val CHANNEL = "square_home/start_overlay"
        const val EXTRA_START_OVERLAY = "start_overlay"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val startOverlay = intent?.getBooleanExtra(EXTRA_START_OVERLAY, false) == true

        if (startOverlay) {
            setTheme(R.style.StartTheme)
        }

        super.onCreate(savedInstanceState)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "closeStartOverlay" -> {
                    if (intent?.getBooleanExtra(EXTRA_START_OVERLAY, false) == true) {
                        finish()
                    }
                    result.success(true)
                }

                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)

        if (intent.getBooleanExtra(EXTRA_START_OVERLAY, false)) {
            setTheme(R.style.StartTheme)
        }
    }
}
